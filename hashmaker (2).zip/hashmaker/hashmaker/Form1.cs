﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace hashmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string data = "Hello, World!"; // Data to be hashed
            string sha384=GetHash(data,new SHA384CryptoServiceProvider());
            MessageBox.Show("SHA384: " + sha384);
            string sha512 = GetHash(data, new SHA512CryptoServiceProvider());
            MessageBox.Show("SHA512: " + sha512);
            string ripemd160hash = GetHash(data, new RIPEMD160Managed());
            MessageBox.Show("Rip: " + ripemd160hash);


        }
        static string GetHash(string input,HashAlgorithm hashAlgorithm)
        {
            byte[] data=hashAlgorithm.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder sb=new StringBuilder();
            foreach(byte b in data)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

    }
}
